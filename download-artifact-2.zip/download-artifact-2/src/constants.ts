export enum Inputs {
  Name = 'name',
  Path = 'path'
}
